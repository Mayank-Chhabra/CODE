<?php
include 'connection.php';

if (isset($_POST['submit'])) 
{  
  
  
$PName = $_POST['PName'];
$Age = $_POST['Age'];
$radio = $_POST['radio'];
$email = $_POST['email'];
/*
if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email))
    {
    // Return Error - Invalid Email
    $msg = 'The email you have entered is invalid, please try again.';
    echo $msg;
    }
else{
    // Return Success - Valid Email   
    }
    */
   
$add = $_POST['add'];
$dist = $_POST['dist'];
$state = $_POST['state'];
$pin = $_POST['pin'];
$patient_num = $_POST['patient_num'];
$family_num = $_POST['family_num'];
$adhar = $_POST['adhar'];
$land=$_POST['land'];

$caugh = $_POST['caugh'];
$fever = $_POST['fever'];
$weight = $_POST['weight'];
$sweat = $_POST['sweat'];
$blood = $_POST['blood'];
$contact = $_POST['contact'];

$referred = $_POST['referred_to'];
//echo "referred=".$referred.";";
$referring = $_POST['referring'];
//echo "referring=".$referring.";";
$by= $_POST['by'];
//echo "referred_BY=".$by.";";

$datee = date("Y-m-d");

$sub = substr($PName, 0, 3);
$p=(rand(10,1000));
$IDI=$sub.$p;


// $chw=$_POST['phw'];

$sql_1 = "INSERT INTO Patient_Personal_Info (Unique_ID, Nikshay_ID,Name, Age, Sex, Address, Landmark, District, PIN, Patient_Mobile, Family_Mobile, Adhaar, CHW_ID)
VALUES ('$IDI', 'NULL', '$PName', '$Age', '$radio', '$add', '$land', '$dist', '$pin', '$patient_num', '$family_num', '$adhar','1')";



if (mysqli_query($conn, $sql_1)) {
    echo "Your unique ID is=".$IDI."<br />";
    echo "Please keep this carefully"; 
} else {
    echo "Error: ".$sql_1."<br>".mysqli_error($conn);
}

$result = mysqli_query($conn, "SELECT MAX(ID) AS MAXID FROM Patient_Personal_Info");
$row=mysqli_fetch_array($result);
$PID=$row['MAXID'];


$sql_2 = "INSERT INTO Patient_Health_Info (PID, Caugh, Fever, Loss_of_Weight, Night_Sweat, Blood_in_Sputum, Contact_of_TB)
VALUES ('$PID', '$caugh', '$fever', '$weight', '$sweat', '$blood', '$contact')";

if (mysqli_query($conn, $sql_2)) {
    //echo "New record created successfully2";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

$sql_3 = "INSERT INTO Referral_Info (PID, Datee, Referred_Lab_ID, Referring_HF_ID, Referred_by_ID) 
VALUES ('$PID', '$datee', '$referred', '$referring', '$by')";

if (mysqli_query($conn, $sql_3)) {
    //echo "New record created successfully3";
} else {
    echo "Error: " . $sql_3 . "<br>" . mysqli_error($conn);
}

}
mysqli_close($conn);
?>
