<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="author" content="">
<meta http-equiv="pragma" content="no-cache">
<title>Slip 1 - Swasthyaa</title>
<link rel="icon" href="favicon.png" type="image/png">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="jquery-ui.min.css" type="text/css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="http://cdn.bootcss.com/animate.css/3.5.1/animate.min.css">
<link rel="stylesheet" href="style.css">
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">


<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
<script src="jquery-ui.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<style>
a {
	color : #000;
}
li{
	border-bottom: solid 0.5px grey; font-size : 12px; opacity: 0.82; font-family: Roboto; text-align: left; color: #000000;
}
</style>
</head>
<body>
<form action="slip1_action.php" method="post" >
<header class="navbar navbar-bright navbar-fixed-top" role="banner">
  <div class="container">
    <div class="navbar-header">
      <button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".navbar-collapse">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a href="/" class="navbar-brand" style="color : #000; margin-left : -46px;">SWASTHYA</a>
    </div>
    <nav class="collapse navbar-collapse" role="navigation">
		<ul class="nav navbar-nav navbar-right">
			<li></li>
			<li></li>
			<li></li>
		</ul>
    </nav>
  </div>
</header>


<!-- Begin Body -->
<div class="container-fluid">
	<div class="row">
  			<div class="col-md-2" id="leftCol" style="background : #e09e43; height : 1200px;">
              	<ul class="nav nav-stacked" id="sidebar" style="width : 100%; margin-top : 10px;">
                  <li><a href="#sec0"><img src="image/ic-donut-large.png" style="width : 18px; height : 18px;"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dashboard</a></li>
                  <li><a href="#sec1"><img src="image/ic-check-box-outline-blank-copy.png" style="width : 15px; height : 15px;"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;New Refferel Slip</a></li>
				  <li><a href="#sec1"><img src="image/ic-remove-red-eye.png" style="width : 15px; height : 15px;"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;View Forwarded Refferel</a></li>
				  <li><a href="#sec1"><img src="image/asha-worker.png" style="width : 15px; height : 15px;"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ASHA Details</a></li>
              	</ul>
              
      		</div>  
      		<div class="col-md-10" id="mainCol" style="padding-left : 0; padding-right:0;">
              <div class="col-md-12" style="width : 100%; height : 60px; background : #e3e6ea; padding : 15px;">
				<div class="col-md-2"><input type="button" class="btn" value="PERSONAL DETAILS" style="color : red;"></div>
				<div class="col-md-1"></div>
				<div class="col-md-2"><input type="button" class="btn" value="HEALTH DETAILS" style="color : red; "></div>
				<div class="col-md-1"></div>
				<div class="col-md-2"><input type="button" class="btn" value="REFRRAL DETAILS" style="color : red; "></div>
				<div class="col-md-2 col-md-offset-2"><img src="image/ic-check-box-outline-blank-copy.png" style="width : 15px; height : 15px;"/>&nbsp;&nbsp;&nbsp;<b style="font-size : 15px; color : grey">New Refferel Slip</b></a></div>
			  </div>
			  
			<div class="col-md-12" style="margin-top : 40px;">
				<div class="col-md-9 col-md-offset-1">
					<p style="font-weight : 600">Patient Name</p>
					<input type="text" class="form-control" name="PName" id="" placeholder="Enter Patient name" style="border-radius : 0;">					
				</div>
			</div>		
			<div class="col-md-12" style="margin-top : 40px;">
				<div class="col-md-9 col-md-offset-1">
					<p style="font-weight : 600">Date of Birth</p>
					<div class="col-md-2" style="padding-left : 0; padding-right:0;">
						<select class="form-control" name="day" id="" style="border-radius : 0;">
							<option disabled selected>Date</option>
                                                  <option>1</option>
                                                  <option>2</option>
                                                  <option>3</option>
                                                  <option>4</option>
                                                  <option>5</option>
                                                  <option>6</option>
                                                  <option>7</option>
                                                  <option>8</option>
                                                  <option>9</option>
                                                  <option>10</option>
                                                  <option>11</option>
                                                  <option>12</option>
                                                  <option>13</option>
                                                  <option>14</option>
                                                  <option>15</option>
                                                  <option>16</option>
                                                  <option>17</option>
                                                  <option>18</option>
                                                  <option>19</option>
                                                  <option>20</option>
                                                  <option>21</option>
                                                  <option>22</option>
                                                  <option>23</option>
                                                  <option>24</option>
                                                  <option>25</option>
                                                  <option>26</option>
                                                  <option>27</option>
                                                  <option>28</option>
                                                  <option>29</option>
                                                  <option>30</option>
                                                  <option>31</option>                                                  
						</select>
					</div>
					<div class="col-md-2" style="padding-left : 0; padding-right:0;">
						<select class="form-control" name="month" id="" style="border-radius : 0;">
							<option disabled selected>Month</option>
                                                  <option value="01">January</option>
                                                  <option value="02">Februry</option>
                                                  <option value="03">March</option>
                                                  <option value="04">April</option>
                                                  <option value="05">May</option>
                                                  <option value="06">June</option>
                                                  <option value="07">July</option>
                                                  <option value="08">August</option>
                                                  <option value="09">September</option>
                                                  <option value="10">October</option>
                                                  <option value="11">November</option>
                                                  <option value="12">December</option>                                                                                                   
						</select>
					</div>
					<div class="col-md-2" style="padding-left : 0; padding-right:0;">
						<select class="form-control" name="year" id="" style="border-radius : 0;">
							<option disabled selected>Year</option>
                                                  <option>2000</option>
                                                  <option>2001</option>
                                                  <option>2002</option>
                                                  <option>2004</option>
                                                  <option>2005</option>
                                                  <option>2006</option>
                                                  <option>2007</option>
                                                  <option>2008</option>
                                                  <option>2009</option>
                                                  <option>2010</option>
                                                  <option>2011</option>
                                                  <option>2012</option>
                                                  <option>2013</option>
                                                  <option>2014</option>
                                                  <option>2015</option>
                                                  <option>2016</option>
                                                  <option>2017</option>                                                                                                    
						</select>
					</div>
					<div class="col-md-2">
						<input type="text" class="form-control" name="Age" id="" placeholder="Age" style="border-radius : 0;">
					</div>
				</div>
			</div>
			<div class="col-md-12" style="margin-top : 40px;">
				<div class="col-md-9 col-md-offset-1">
					<p style="font-weight : 600">Sex</p>
					<div class="col-md-2" style="padding-left : 0; padding-right:0;">
						Female &nbsp;&nbsp;<input type="radio" name="gender" value="Male" checked> 
					</div>
					<div class="col-md-2">
						Male &nbsp;&nbsp;<input type="radio" name="gender" value="Female"> 
					</div>
					<div class="col-md-2">
						Other &nbsp;&nbsp;<input type="radio" name="gender" value="Other"> 
					</div>
				</div>
			</div>
			<div class="col-md-12" style="margin-top : 40px;">
				<div class="col-md-9 col-md-offset-1">
					<p style="font-weight : 600">Address</p>
					<div class="col-md-12" style="padding-left : 0; padding-right:0;">
						<input type="text" class="form-control" name="add" id="" placeholder="Enter House Number" style="border-radius : 0;">
					</div>
					<div class="col-md-12" style="padding-left : 0; padding-right:0; margin-top: 15px;">
						<input type="text" class="form-control" name="land" id="" placeholder="Enter Locality" style="border-radius : 0;">
					</div>
					<div class="col-md-4" style="padding-left : 0; padding-right:0; margin-top: 15px;">
						<input type="text" class="form-control" name="pin" id="" placeholder="Enter Pin Code" style="border-radius : 0;">
					</div>
					<div class="col-md-4" style="margin-top: 15px; ">
						<select class="form-control" name="dist" id="" style="border-radius : 0;">
							<option>Kamrup Metropolitan</option>
                                                  <option>Barpeta</option>
                                                  <option>Biswanath</option>
                                                  <option>Bongaigaon</option>
                                                  <option>Cachar</option>
                                                  <option>Charaideo</option>
                                                  <option>Chirang</option>
                                                  <option>Darrang</option>
                                                  <option>Dhemaji</option>
                                                  <option>Dhubri</option>
                                                  <option>Dibrugarh</option>
                                                  <option>Goalpara</option>
                                                  <option>Golaghat</option>
                                                  <option>Hailakandi</option>
                                                  <option>Hojai</option>
                                                  <option>Jorhat</option>
                                                  <option>Baksa</option>
                                                  <option>Kamrup</option>
                                                  <option>Karbi Anglong</option>
                                                  <option>Karimganj</option>
                                                  <option>Kokrajhar</option>
                                                  <option>Lakhimpur</option>
                                                  <option>Majuli</option>
                                                  <option>Morigaon</option>
                                                  <option>Nagaon</option>
                                                  <option>Nalbari</option>
                                                  <option>Dima Hasao</option>
                                                  <option>Sivasagar</option>
                                                  <option>Sonitpur</option>
                                                  <option>South Salmara-Mankachar</option>
                                                  <option>Tinsukia</option>
                                                  <option>Udalguri</option>
                                                  <option>West Karbi Anglong</option>
						</select>
					</div>
					
					<div class="col-md-4" style="margin-top: 15px; padding-left : 0; padding-right:0;">
						<select class="form-control" name="" id="" style="border-radius : 0;">
							<option value="Assam">Assam</option>
						</select>
					</div>
				</div>
			</div>
			<div class="col-md-12" style="margin-top : 40px;">
				<div class="col-md-9 col-md-offset-1">
					<p style="font-weight : 600">Patient's Mobile Number</p>
					<div class="col-md-2" style="padding-left : 0; padding-right:0;">
						Yes &nbsp;&nbsp;<input type="radio" name="number" value="yes" checked> 
					</div>
					<div class="col-md-2">
						No &nbsp;&nbsp;<input type="radio" name="number" value="no"> 
					</div>
					<div class="col-md-4">
						<input type="text" class="form-control" name="patient_num" id="" placeholder="Enter Mobile Number" style="border-radius : 0;">
					</div>
				</div>
			</div>
			<div class="col-md-12" style="margin-top : 40px;">
				<div class="col-md-9 col-md-offset-1">
					<p style="font-weight : 600">Family Member Mobile Number</p>
					<div class="col-md-4" style="padding-left : 0; padding-right:0;">
						<input type="text" class="form-control" name="family_num" id="" placeholder="Enter Mobile Number" style="border-radius : 0;">
					</div>
				</div>
			</div>
			<div class="col-md-12" style="margin-top : 40px;">
				<div class="col-md-9 col-md-offset-1">
					<p style="font-weight : 600">For Patient Mobile Verification call on</p>
					<b style="font-weight : 600; color : red; font-size : 16px;">99999955555</b>&nbsp;&nbsp;from patient registered mobile number
				</div>
			</div>
			<div class="col-md-12" style="margin-top : 40px; text-align : center;">
				<div class="col-md-6 col-md-offset-3">
					<input type="button" class="btn btn-primary" value="RESET" style="background : red; border-radius : 0; border : none; margin : 30px;">
					<input type="submit" name="submit" class="btn btn-primary" value="NEXT" style="background : red; border-radius : 0; border : none;">
				</div>
			</div>
  	</div>
</div>
<script type="text/javascript">
      
</script>		
</body>
</html>