<!DOCTYPE html>
<html lang="eng">
<head>
      <title> Swasthyaa</title>
    <style>
 #up1, #up2 { display : none; }
 h2
    {
     text-align:center ;  
    }
	
  .toggle.android { border-radius: 20px;}
  .toggle.android .toggle-handle { border-radius: 20px; }
.inset {
  width: 30px;
  height: 30px;
  margin-bottom:-8px;
  border-radius: 50%;
  box-shadow:
    inset 0 0 0 2px rgba(255,255,255,0.6), 
    0 1px 1px rgba(0,0,0,0.1);
  background-color: transparent !important;
  z-index: 999;
}

.inset img {
  border-radius: inherit;
  width: inherit;
  height: inherit;
  display: block;
  position: relative;
  z-index: 998;
}
 </style>
<script>
        function slide1(){
            //alert("hi");
     /*   if(document.getElementById("51").value == "yes"){
        document.getElementById("up1").style.display="block";
        document.getElementById("up2").style.display="none";
        }
        else*/ if(document.getElementById("51").value == "no") {
           // document.getElementById("up1").style.display="none";
            document.getElementById("up2").style.display="block";
           document.getElementById("up3").style.display="none";
        } 
        else {
          //  document.getElementById("up1").style.display="none";
            document.getElementById("up2").style.display="none";
        }
    }
	      function slide2(){
            //alert("hi");
     /*   if(document.getElementById("51").value == "yes"){
        document.getElementById("up1").style.display="block";
        document.getElementById("up2").style.display="none";
        }
        else*/ if(document.getElementById("51").value == "no") {
           // document.getElementById("up1").style.display="none";
            document.getElementById("up2").style.display="block";
           document.getElementById("up3").style.display="none";
        } 
        else {
          //  document.getElementById("up1").style.display="none";
            document.getElementById("up2").style.display="none";
        }
    }
</script>
<script   src="https://code.jquery.com/jquery-3.1.1.js"   integrity="sha256-
16cdPddA6VdVInumRGo6IbivbERE8p7CQR3HzTBuELA="   crossorigin="anonymous">  
    </script>
    <script>
        function getId(val){
           
            District=val;
            //We create ajax function
            $.ajax({
                type: 'POST',
                url: 'getdata.php',
                data: {
                    D_Name:District
                    },
                success: function(data){
                    $("#referred").html(data);
                }
            });
        }
    </script>
    
    <script>
        function getphw(val){
           
            Area=val;
            //We create ajax function
            $.ajax({
                type: 'POST',
                url: 'getdata2.php',
                data: {
                    Area_Name:Area
                    },
                success: function(data){
                    $("#phw").html(data);
                }
            });
        }
    </script>
<script>
$(document).ready(function() {
    
    var navListItems = $('ul.setup-panel li a'),
        allWells = $('.setup-content');

    allWells.hide();

    navListItems.click(function(e)
    {
        e.preventDefault();
        var $target = $($(this).attr('href')),
            $item = $(this).closest('li');
        
        if (!$item.hasClass('disabled')) {
            navListItems.closest('li').removeClass('active');
            $item.addClass('active');
            allWells.hide();
            $target.show();
        }
    });
    
    $('ul.setup-panel li.active a').trigger('click');
    
    // DEMO ONLY //
    $('#activate-step-2').on('click', function(e) {
        $('ul.setup-panel li:eq(1)').removeClass('disabled');
        $('ul.setup-panel li a[href="#step-2"]').trigger('click');
        $(this).remove();
    })
    
    $('#activate-step-3').on('click', function(e) {
        $('ul.setup-panel li:eq(2)').removeClass('disabled');
        $('ul.setup-panel li a[href="#step-3"]').trigger('click');
        $(this).remove();
    })
    
    $('#activate-step-4').on('click', function(e) {
        $('ul.setup-panel li:eq(3)').removeClass('disabled');
        $('ul.setup-panel li a[href="#step-4"]').trigger('click');
        $(this).remove();
    })
    
    $('#activate-step-3').on('click', function(e) {
        $('ul.setup-panel li:eq(2)').removeClass('disabled');
        $('ul.setup-panel li a[href="#step-3"]').trigger('click');
        $(this).remove();
    })
});

</script>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
  
<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesnt work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <!--Action-->
    <form action="referral_slip_action.php" method="post" >
    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html" style="color: #021048;"> SWASTHYAA</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
           <!--     <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-envelope fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-messages">
                        <li>
                            <a href="#">
                                <div>
                                    <strong>John Smith</strong>
                                    <span class="pull-right text-muted">
                                        <em>Yesterday</em>
                                    </span>
                                </div>
                                <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">
                                <div>
                                    <strong>John Smith</strong>
                                    <span class="pull-right text-muted">
                                        <em>Yesterday</em>
                                    </span>
                                </div>
                                <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">
                                <div>
                                    <strong>John Smith</strong>
                                    <span class="pull-right text-muted">
                                        <em>Yesterday</em>
                                    </span>
                                </div>
                                <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a class="text-center" href="#">
                                <strong>Read All Messages</strong>
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </li>
                    </ul>
                    <!-- /.dropdown-messages -->
                </li>
                <!-- /.dropdown -->
           <!--     <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-tasks fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-tasks">
                        <li>
                            <a href="#">
                                <div>
                                    <p>
                                        <strong>Task 1</strong>
                                        <span class="pull-right text-muted">40% Complete</span>
                                    </p>
                                    <div class="progress progress-striped active">
                                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
                                            <span class="sr-only">40% Complete (success)</span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">
                                <div>
                                    <p>
                                        <strong>Task 2</strong>
                                        <span class="pull-right text-muted">20% Complete</span>
                                    </p>
                                    <div class="progress progress-striped active">
                                        <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width: 20%">
                                            <span class="sr-only">20% Complete</span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">
                                <div>
                                    <p>
                                        <strong>Task 3</strong>
                                        <span class="pull-right text-muted">60% Complete</span>
                                    </p>
                                    <div class="progress progress-striped active">
                                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
                                            <span class="sr-only">60% Complete (warning)</span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">
                                <div>
                                    <p>
                                        <strong>Task 4</strong>
                                        <span class="pull-right text-muted">80% Complete</span>
                                    </p>
                                    <div class="progress progress-striped active">
                                        <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                                            <span class="sr-only">80% Complete (danger)</span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a class="text-center" href="#">
                                <strong>See All Tasks</strong>
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </li>
                    </ul>
                    <!-- /.dropdown-tasks -->
                </li>
                <!-- /.dropdown -->
              <li>
		 </li>
                <!-- /.dropdown -->
               <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-bell fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-alerts">
                        <li>
                            <a href="#">
                                <div>
                                    <i class="fa fa-comment fa-fw"></i> Rs 5 talktime succesful
                                    <span class="pull-right text-muted small">4 minutes ago</span>
                                </div>
                            </a>
                        </li>
                        
                        <li class="divider"></li>
                        <li>
                            <a class="text-center" href="#">
                                <strong>See all notifications</strong>
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </li>
                    </ul>
                    <!-- /.dropdown-alerts -->
                </li>
				 <li>
                <div class="inset">
				</div>
				</li>
                <!-- /.dropdown -->
                <li class="dropdown">
				  
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        Sangeeta Saikia <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>                        
                        <li class="divider"></li>
                        <li><a href="login.html"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

             <div class="navbar-default sidebar"   role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        
                           <li style=" color: black;">
                            <a href="index.php"><img src="d.png"></i>&nbsp; Dashboard</a>
                        </li>
                      <li>
                            <a href="new_patient.php"><img src="edit.png"></i>&nbsp; New referral slip</a>
							
                        </li>
                       
						 <li>
                            <a href="forw_patient.php"><img src="eye.png"></i>  View forwarded referral slip</a>
							
                        </li>
                       <li>
                            <a href="asha_list.php"><img src="pro.png"></i>&nbsp; ASHA Details</span></a>
							
                        </li>
                         <li>
                            <a href="anm_pro.php"><img src="p.png"></i>&nbsp; Profile</span></a>
							
                        </li>
                    </ul>
                </div>
            <!-- /.navbar-static-side -->
        </nav>
		
        <div id="page-wrapper">
		
		
		
          
            <!-- /.row -->
           
                        
                        <div class="panel-body" style="margin-top:-15px; ">
                            <div class="row form-group" style=" border-top: 11px solid #f1635d; background-color: #f4f4f5;  box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.14);  margin:0 -3.5vw;">
        <div class="col-xs-12"   >
            <ul class="nav nav-pills nav-justified setup-panel">
			
                <li class="active"  style=" float: left;  color:#f1635d;  "><a href="#step-1">
                    <h6 class="list-group-item-heading" >PERSONAL DETAILS</h6>
                 </a></li>
                <li class="disabled" style="  float: left;   color:#f1635d;"><a href="#step-2">
                    <h6 class="list-group-item-heading">HEALTH DETAILS</h6>
                 </a></li>
                <li class="disabled" style="   float: left;  color:#f1635d;"><a href="#step-3">
                    <h6 class="list-group-item-heading">REFERRAL DETAILS</h6>
                 </a></li>    
				<h4  style=" float: right; color: #a0a0a0; margin-top:7px; margin-left: 1vw;" >New Referral Slip</h4><i class="fa fa-edit fa-fw  " style=" color: #a0a0a0;  margin-top:10px;float: right;"></i>
            
		   </ul>
        </div>
	</div>
							 <form >
                             <div class="row setup-content" id="step-1">
                                <div class="col-lg-7">
                                      <br>
									  <br>
									  
                                        <div class="form-group">
                                            <label>Patient Name</label>
                                            <input name="PName" type="text"  placeholder="Enter Patient Name" class="form-control" >
                                        </div>
										
										<label>Date of Birth</label>
										 <div class="form-inline">
												<div class="form-group"  >
												<select name="dist" style=" width: 8vw; margin-right:2vw;" placeholder=" Date" class="form-control">
												                                          <option selected>Date</option>

												</select>
												</div>
												<div class="form-group">
												<select name="dist" style=" width: 8vw; margin-right:2vw;" placeholder=" Month" class="form-control">
												        <option selected>Month</option>

												</select>
												</div>
												<div class="form-group">
												<select name="dist" style=" width: 8vw; margin-right:2vw;" placeholder=" Year" class="form-control">
												    <option selected>Year</option>

												</select>
												</div>
												<div class="form-group">
                                            <input name="Age"  style=" width: 8vw;" type="text" class="form-control" placeholder="Enter Age">
												</div>
										 </div>
										<br>
										  <label>Sex</label>
										 <div class="form-inline">
                                           
                                            <div class="radio">
                                                <label>
												 Female&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="radio" value="Female" checked>
                                                </label>
                                            </div>
                                            <div class="radio" style="margin-left: 1.25vw;">
                                                <label>
                                                                 Male &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <input type="radio" name="radio" value="Male" >

                                                </label>
                                            </div>
                                            <div class="radio" style="margin-left: 1.25vw;">
                                                <label>
                                                   TG&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="radio" value="Other">
													</label>
                                            </div>
											 
											
											 
                                        </div>
										<br>
										<div class="form-group">
                                            <label>Address</label>
                                            <input name="add" type="text" class="form-control"  placeholder=" Enter House No." >
                                            <!--<textarea name="add" type="text" class="form-control" rows="3"></textarea> -->
                                        </div>
										<div class="form-group">
                                             <input name="land" type="text" class="form-control"  placeholder=" Enter Locality" >
                                        </div>
                                        <div class="form-inline">
										<div class="form-group">
                                             <input name="land" type="text" class="form-control"style=" width: 11vw; margin-right:2vw;" placeholder=" Enter PIN Code" >
                                        </div>
                                            <select name="dist" class="form-control" style="width: 11vw; margin-right:2vw;"  >
                                                  <option>Kamrup  </option>
                                                  <option>Barpeta</option>
                                                  <option>Biswanath</option>
                                                  <option>Bongaigaon</option>
                                                  <option>Cachar</option>
                                                  <option>Charaideo</option>
                                                  <option>Chirang</option>
                                                  <option>Darrang</option>
                                                  <option>Dhemaji</option>
                                                  <option>Dhubri</option>
                                                  <option>Dibrugarh</option>
                                                  <option>Goalpara</option>
                                                  <option>Golaghat</option>
                                                  <option>Hailakandi</option>
                                                  <option>Hojai</option>
                                                  <option>Jorhat</option>
                                                  <option>Baksa</option>
                                                  <option>Kamrup</option>
                                                  <option>Karbi Anglong</option>
                                                  <option>Karimganj</option>
                                                  <option>Kokrajhar</option>
                                                  <option>Lakhimpur</option>
                                                  <option>Majuli</option>
                                                  <option>Morigaon</option>
                                                  <option>Nagaon</option>
                                                  <option>Nalbari</option>
                                                  <option>Dima Hasao</option>
                                                  <option>Sivasagar</option>
                                                  <option>Sonitpur</option>
                                                  <option>South Salmara-Mankachar</option>
                                                  <option>Tinsukia</option>
                                                  <option>Udalguri</option>
                                                  <option>West Karbi Anglong</option>
                                            </select>
											 
                                        </div>
                                        
									<br>
									<div class="form-inline">

					<label>Patient mobile number</label>
											
				<select name="51" id="51" onchange="slide1()" class="form-control">
                                           <option value="yes" selected>Yes</option>
                                           <option value="no">No</option>
                                 </select>
                                 <!-- <input type="text" name="patient_num" > -->

                                 <div id="up2">
                                 <br>
	                             <label>Assign ASHA<span style="color:#d0011b; font-size: 12px; "> (As patient does not have mobile, please assign a temporary ASHA) </span></label><br>
								 
                                 <div class="form-inline">
                                            <label style="width: 10vw;">District:</label>
											 <select name="referred" class="form-control" onchange="getId(this.value);" id="" required style="width: 12vw;">
                                          <option selected>--Select district--</option>
                                          <?php 
                                              include 'connection.php';
												$result = mysqli_query($conn,"select distinct District from Health_Admin_Info where Designation='STS' order by District");
														  while($row = mysqli_fetch_array($result))
															 {
																echo "<option value=".$row['District'].">".$row['District']."</option>";
															 }
                                           ?>                                                                 
                                    </select> 
                                 </div>
                                   <div class="form-inline">
                                            <label style="width: 10vw;">Area:</label>
                           <select name="referred"  class="form-control"  onchange="getphw(this.value);" id="referred" required style="width: 12vw;">
                                          <option selected>--Select area--</option>
                                          <?php 
                                              include 'connection.php';
												$result = mysqli_query($conn,"select distinct Area from Health_Admin_Info where Designation='STS' order by Area");
														  while($row = mysqli_fetch_array($result))
															 {
																echo "<option value=".$row['Area'].">".$row['Area']."</option>";
															 }
                                           ?>                                                                 
                                    </select> 
                                 </div>                         
										 <div class="form-inline">
                                            <label style="width: 10vw;">ASHA name:</label>
                           <select name="referred"  class="form-control"  onchange="getphw(this.value);" id="referred" required style="width: 12vw;">
                                          <option selected>--Select ASHA --</option>
                                          <?php 
                                              include 'connection.php';
												$result = mysqli_query($conn,"select distinct Name from Health_Admin_Info where Designation='STS' order by Name");
														  while($row = mysqli_fetch_array($result))
															 {
																echo "<option value=".$row['Name'].">".$row['Name']."</option>";
															 }
                                           ?>                                                                 
                                    </select> 
                                 </div> 
                                                         
                        </div>               
				</div>
					     <div class="input-group" id="up3">
		  <span class="input-group-addon">+91</span>

		<input type="text" name="patient_num" placeholder="Patient mobile no." class="form-control" >
	     </div> <br>

									
        <label>Mobile number of any family member</label>
		<div class="input-group">
		  <span class="input-group-addon">+91</span>

		<input type="text" name="family_num" placeholder="Family mobile no." class="form-control" >
	     </div>
		 <br>
										<div class="form-group">
                                            <label>Family Member Mobile Number</label>
                                            <input name="adhar"  class="form-control" placeholder= "Enter Mobile Number">
                                        </div>
										<br>
                                        <label  >For Patient mobile verification call on</label>
										
										<label> <span style="color:#d0011b; font-size: 18px;">9999555500</span> from patient registered mobile number.</label>
                                     
										 <br>
                                       								<button type="submit" id="activate-step-2" class="btn btn-default"  data-toggle="modal" data-target="#myModal" value="submit">Next</button>

                                       
                                </div>
								</div>
								                             <div class="row setup-content" id="step-2">

                                <!-- /.col-lg-6 (nested) -->
                                <div class="col-lg-6">
                                    <h3>Patient health details</h3>
                                    
									        
											 <label>Cough</label>											
                                        <div class="form-group input-group" style=" width: 10vw;" >
											
                                            <input name="caugh" type="text" class="form-control">
                                            <span class="input-group-addon">days</span>
                                        </div>
										<label>Fever</label>
                                        <div class="form-group input-group" style=" width: 10vw;">
											
                                            <input name="fever" type="text" class="form-control">
                                            <span class="input-group-addon">days</span>
                                        </div>
                                       <label>Loss of weight</label>
                                        <div class="form-group input-group" style=" width: 10vw;">
											
                                            <input name="weight" type="text" class="form-control">
                                            <span class="input-group-addon">days</span>
                                        </div>
										<label>Night Sweat</label>
                                        <div class="form-group input-group" style=" width: 10vw;">
											
                                            <input name="sweat" type="text" class="form-control">
                                            <span class="input-group-addon">days</span>
                                        </div>
										<label>Blood in Cough/Sputum</label>
                                        <div class="form-group input-group" style=" width: 10vw;">
											
                                            <input name="blood" type="text" class="form-control">
                                            <span class="input-group-addon">days</span>
                                        </div>										
										<div class="form-inline">
                                            <label>Contact of TB/MDR TB</label> <br>
                                            <input type="radio" name="contact" value="Yes" checked> Yes<br>
                                            <input type="radio" name="contact" value="No"> No<br>
                                        </div>
                                                                           								<button type="submit"  class="btn btn-default" id="activate-step-3" data-toggle="modal" data-target="#myModal" value="submit">Next</button>
									</div>
									</div>
																	                             <div class="row setup-content" id="step-3">

                                    <h3>Referral details</h3>
                                     <?php
                                       $result = mysqli_query($conn,"select * from HF_Info"); 
                                      ?>
                                    <div class="form-group">
                                            <label>Lab referred to</label>
                                            <select name="referred_to" onchange="" id="" class="form-control" required>
                                                <option value="0" selected>--Select referred lab--</option>  
                                             
                                               <?php
                                                
                                               include 'connection.php';
                                              $result = mysqli_query($conn,"select * from HF_Info order by Name");
                                                while($row = mysqli_fetch_array($result))
                                                    {
                                                        echo "<option value=".$row['ID'].">".$row['ID'].".".$row['Name'].",".$row['Location']."</option>";
                                                        }
                                                
                                                ?>
                                            </select>
                                    </div>
										  <div class="form-group">
                                            <label>Name of referrring HF</label>
                                            <select name="referring" onchange="" id="" required class="form-control">
                                                <option selected>--Select referring HF--</option>    
                                                   <?php 
                                                   include 'connection.php';
                                                  $result = mysqli_query($conn,"select * from HF_Info order by Name");
                                                    while($row = mysqli_fetch_array($result))
                                                        {
                                                            echo "<option value=".$row['ID'].">".$row['ID'].".".$row['Name'].",".$row['Location']."</option>";
                                                            }
                                                    ?>
                                            </select>

                                        </div>
									 																					
											<div class="form-group">
                                            <label>Reffered by</label>
                                            <select name="by" onchange="" id="" required class="form-control">
                                                <option selected>--Select who referred--</option>
                                                 <?php 
                                                  $result = mysqli_query($conn,"select * from Health_Admin_Info order by Name");
                                                     while($row = mysqli_fetch_array($result))
                                                         {
                                                        echo "<option value=".$row['ID'].">".$row['Name']."</option>";
                                                        }
                                                ?>
                                            </select>
                                        </div>
																 <br>
							 <div class="row">
								<div class="col-lg-6">							 
								<button type="submit" name="submit" class="btn btn-default"  data-toggle="modal" data-target="#myModal" value="submit">Forward to Lab Technichian</button>
									<button type="reset" class="btn" style=" color:black !important;background-color:#e6e6e6 !important; border-color:#adadad; margin-left: 14px;">Reset</button>

										</div>		
								</div>			
									</div>
                                   
                                
							 

                             </form>
                           

                         


							 <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
          
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
